# CSS Responsive Table Layout

A Pen created on CodePen.io. Original URL: [https://codepen.io/lukepeters/pen/JjoVWd](https://codepen.io/lukepeters/pen/JjoVWd).

Using CSS for responsive table layouts instead of floats. Responsive (everything goes down to one row each), too.